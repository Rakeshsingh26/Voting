var express = require("express");
var bodyParser = require("body-parser");
var mysql = require("mysql");
var connection = mysql.createConnection({
    host: 'localhost:8000',
    user: 'root',
    password: '',
    database: 'database'
});

var app = express();
app.use(bodyParser.urlencoded({ extended: false }));




app.listen('8000', () => {
    console.log("connected")
});