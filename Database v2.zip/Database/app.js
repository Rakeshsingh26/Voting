var express = require("express");
var bodyParser = require("body-parser");
var mysql = require("mysql");
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', 
    database: 'Database'
});
  
var app = express();
app.use(bodyParser.urlencoded({ extended: true}));
app.use(express.static("public"));
app.set("view engine","ejs");

//Database connection  
//  ====================================================================================== // 

connection.connect((err) => {
    if (err) throw err;
    else
    console.log("running");
});

//  ====================================================================================== // 

//          Get Home page request
 
//  ====================================================================================== // 

app.get("/", (req, res) => {
    res.send("Home page with navigation");
});

//Get request for admin page
app.get("/admin", (req, res) => {
    // res.sendFile("admin.html", { root: __dirname }, (err) => {
    //     if (err)
    //         console.log(err);
    //     else
    //         console.log("admin page");
    // });

    res.render("admin");
});

//      Post request for admin page

app.post("/admin/submit", (req, res) => {

     var sql = "insert into admin values('" + req.body.username + "','" + req.body.password + "')";

    var dis = "select * from admin";

    connection.query(sql, function (err) {
        if (err) {
            console.log("error");
        }
        else
            connection.query(dis, function (err, result) {
                if (err) {
                    console.log("error");
                }
                else {
                    res.send("Entered successfully");
                    console.log(result);
                }
            });
    });
});

//  ====================================================================================== // 


//      get request for candidate page

//  ====================================================================================== // 
 
app.get("/candidate",(req ,res)=>{
    res.render("candidate");
});

//      post request of candidate page

app.post("/candidate/submit",(req,res)=>{
   
     console.log(req.body.sid);
    
});

//      get request for Student page

//  ====================================================================================== // 
 
app.get("/student",(req ,res)=>{
    res.render("Student");
});

//      post request of student page

app.post("/student/submit",(req,res)=>{
    console.log(req.body.name);
    
});


//  ====================================================================================== // 

app.listen('4000', () => { 
    console.log("connected")
});